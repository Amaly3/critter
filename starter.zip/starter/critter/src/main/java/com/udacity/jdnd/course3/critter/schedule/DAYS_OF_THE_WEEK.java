package com.udacity.jdnd.course3.critter.schedule;

public enum DAYS_OF_THE_WEEK {
    SUN,
    MON,
    TUE,
    WED,
    THU,
    FRI,
    SAT;
}